import os
import requests
import json


class PurchaseService:
    def __init__(self):
        self.base_url = os.getenv("PAYSECURE_API_BASE_URL") + "/api/v1/purchases"
        self.api_key = os.getenv("PAYSECURE_API_KEY")
        self.debug = os.getenv("PAYSECURE_DEBUG")
    
    def create_purchase(self, data: dict):
        
        if self.debug:
            print("[DEBUG] Starting Purchase Service...")
            print("[DEBUG]  PAYSECURE_URL:", self.base_url)
            print("[DEBUG] PAYSECURE_API_KEY:", self.api_key)
            print("[DEBUG] Data entered:\n", json.dumps(data, indent=4))

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }

        response = requests.post(self.base_url, json=data, headers=headers)

        if self.debug:
            print("[DEBUG] Purchase Service Ended.")
            

        return response.json()
    
    def create_purchase_from_file(self, file_path: str):

        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")

        with open(file_path, "r") as file:
            data = json.load(file)

        return self.create_purchase(data)