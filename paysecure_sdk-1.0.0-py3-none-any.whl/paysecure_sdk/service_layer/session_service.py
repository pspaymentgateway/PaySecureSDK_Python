import os
import json
import requests

class SessionService:
    def __init__(self):
        self.base_url = os.getenv("PAYSECURE_API_BASE_URL") + "/api/v1/createSession"
        self.api_key = os.getenv("PAYSECURE_API_KEY")
        self.debug = os.getenv("PAYSECURE_DEBUG", "false").lower() in ("true", "1", "yes")
        

    def create_session(self, data: dict):

        brand_id = data.pop("brandid", "")
        sub_brand_id = data.pop("subbrandid", "")

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
            "Accept": "*/*",
            "brandid": brand_id,
            "subbrandid": sub_brand_id
        }

        if self.debug:
            print("[DEBUG] Starting Purchase Service...")
            print("[DEBUG]  PAYSECURE_URL:", self.base_url)
            print("[DEBUG] PAYSECURE_API_KEY:", self.api_key)
            print("[DEBUG]", brand_id)
            print("[DEBUG] Data entered:\n", json.dumps(data, indent=4))

        response = requests.post(self.base_url, json=data, headers=headers)

        if self.debug:
            print("Session service ended")

        try:
            return response.json()
        except ValueError:
            return {"error": "Invalid JSON response", "raw": response.text}

    def create_session_from_file(self, file_path: str):
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        with open(file_path, "r") as f:
            data = json.load(f)
        return self.create_session(data)
