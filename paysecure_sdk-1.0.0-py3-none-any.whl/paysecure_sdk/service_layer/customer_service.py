import os
import json
import requests

class CustomerService:
    def __init__(self):
        self.base_url = os.getenv("PAYSECURE_API_BASE_URL") + "/api/v1/customer"
        self.api_key = os.getenv("PAYSECURE_API_KEY")
        self.debug = os.getenv("PAYSECURE_DEBUG")


    def create_customer(self, data: dict):
    
        brand_id = data.pop("brandid", "")

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
            "Accept": "*/*",
            "brandid": brand_id,
        }

        if self.debug:
            print("[DEBUG] Starting Customer Service...")
            print("[DEBUG]  PAYSECURE_URL:", self.base_url)
            print("[DEBUG] PAYSECURE_API_KEY:", self.api_key)
            print("[DEBUG] Brand ID" , brand_id)    
            print("[DEBUG] Data entered:\n", json.dumps(data, indent=4))

        response = requests.post(self.base_url, json=data, headers=headers)

        if self.debug:
            print("[DEBUG] Customer Service Ended.")

        try:
            return response.json()
        except ValueError:
            return {"error": "Invalid JSON response", "raw": response.text}

    def create_customer_from_file(self, file_path: str):

        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")

        with open(file_path, "r") as file:
            data = json.load(file)

        return self.create_customer(data)
