import os
import json
import requests

class PayoutService:
    def __init__(self):
        self.base_url = os.getenv("PAYSECURE_API_BASE_URL") + "/api/v1/payout/"
        self.api_key = os.getenv("PAYSECURE_API_KEY")
        self.debug = os.getenv("PAYSECURE_DEBUG")


    def create_payout(self, data: dict):

        headers = {
            "Content-type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }

        if self.debug:
            print("[DEBUG] Starting Payout Service...")
            print("[DEBUG]  PAYSECURE_URL:", self.base_url)
            print("[DEBUG] PAYSECURE_API_KEY:", self.api_key)
            print("[DEBUG] Data entered:\n", json.dumps(data, indent=4))

        response = requests.post(self.base_url, json=data, headers=headers)

        if self.debug:
            print("[DEBUG] Payout Service Ended.")

        return response.json()

    def create_payout_from_file(self, file_path: str):
        """Reads JSON data from a file and creates a payout."""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")

        with open(file_path, "r") as file:
            data = json.load(file)

        return self.create_payout(data)
